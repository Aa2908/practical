sentence = "this is a sentence containing some letters"
unique_letters = {x for x in sentence}
print(unique_letters)
