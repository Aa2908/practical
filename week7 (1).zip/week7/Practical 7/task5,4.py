staff = {"John", "Paul", "George"}
directors = {"George", "Paul", "Steven"}

symmetric_difference_result = staff.symmetric_difference(directors)
