staff = {"Pete", "Kelly", "Jon", "Paul", "Sally", "Sue"}
help(set)