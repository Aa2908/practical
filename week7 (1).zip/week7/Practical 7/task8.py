suits = frozenset({"heart", "club", "spade", "diamond"})
help(frozenset)

