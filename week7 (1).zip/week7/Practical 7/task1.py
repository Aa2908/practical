names = {"John", "Eric", "Terry", "Michael", "Graham", "Terry"}
print(names)
