staff = {"John", "Paul", "George"}
directors = {"George", "Paul", "Steven"}

intersection_result = staff.intersection(directors)