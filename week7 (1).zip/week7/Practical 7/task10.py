stock = {"apple": 20, "pear": 50, "orange": 11}
stock["kiwi"] = 10  # Adding "kiwi" with an initial stock level of 10
