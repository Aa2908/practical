staff = {"John", "Paul", "George"}
directors = {"George", "Paul", "Steven"}

difference_result = staff.difference(directors)