vowels = {"a", "e", "i"}  # initial set of vowels
vowels.update({"o", "u"})  #  update() method to add "o" and "u" to the set
