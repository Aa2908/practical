import math

roots = {n: math.sqrt(n) for n in range(1, 26)}
print(roots)
