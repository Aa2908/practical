# Initial sets
staff = {"John", "Paul", "George"}
directors = {"George", "Paul", "Steven"}


union_result = staff.union(directors)


