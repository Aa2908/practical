
stock = {"apple": 20, "pear": 50, "orange": 11, "kiwi": 10}  # Assuming this is the stock dictionary
print("Initial stock:", stock)

# Removing a specific item using pop()
removed_item = stock.pop("kiwi")
print("Removed item:", removed_item)
print("Stock after removing 'kiwi':", stock)
