known_names = {"John", "Eric", "Terry", "Michael", "Graham", "Terry"} 
input_name = "Bob" 

if input_name not in known_names:
    print(f"{input_name} is not in the set of known names.")
else:
    print(f"{input_name} is in the set of known names.")
