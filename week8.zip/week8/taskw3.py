name = "John"
age = 25.456

print(f"{name: >20} - ${age: >17.2f}")
# Output: John                   - $25.456