r = 52

area = 3.14159 * r**2  

output_message = "A circle with radius {} has an area of {:.13f}".format(r, area)
print(output_message)
