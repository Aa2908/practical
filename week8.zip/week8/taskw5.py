name = "Alice"
age = 30
height = 5.8

output_message = "My name is {}, I am {} years old, and my height is {:.2f} feet.".format(name, age, height)
print(output_message)
